const Database = require("better-sqlite3");
const { DB_PATH } = require("./config");

const db = new Database(DB_PATH);
db.pragma("foreign_keys = ON");

function createTables() {
    db.prepare(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            phone TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            purchase_pin TEXT,
            balance REAL NOT NULL DEFAULT 0,
            virtual_account_number TEXT,
            virtual_bank_name TEXT,
            kyc_status TEXT NOT NULL DEFAULT 'pending',
            is_admin INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    `).run();


    db.prepare(`
        CREATE TABLE IF NOT EXISTS data_plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            network TEXT NOT NULL,
            plan TEXT NOT NULL,
            provider_cost REAL NOT NULL DEFAULT 0,
            selling_price REAL NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            provider TEXT,
            provider_code TEXT,
            provider_package_code TEXT,
            provider_package_name TEXT,
            data_size TEXT,
            validity TEXT,
            source TEXT,
            last_synced_at TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(network, plan)
        )
    `).run();

    const defaultPlans = [
        ["MTN", "1GB", 230, 250],
        ["MTN", "2GB", 460, 500],
        ["MTN", "5GB", 1150, 1250],
        ["MTN", "10GB", 2300, 2500],
        ["MTN", "20GB", 4600, 5000],
        ["MTN", "40GB", 9200, 10000],
        ["Airtel", "1GB", 230, 250],
        ["Airtel", "2GB", 460, 500],
        ["Airtel", "5GB", 1150, 1250],
        ["Airtel", "10GB", 2300, 2500],
        ["Airtel", "20GB", 4600, 5000],
        ["Airtel", "40GB", 9200, 10000],
        ["Glo", "1GB", 230, 250],
        ["Glo", "2GB", 460, 500],
        ["Glo", "5GB", 1150, 1250],
        ["Glo", "10GB", 2300, 2500],
        ["Glo", "20GB", 4600, 5000],
        ["Glo", "40GB", 9200, 10000],
        ["9mobile", "1GB", 230, 250],
        ["9mobile", "2GB", 460, 500],
        ["9mobile", "5GB", 1150, 1250],
        ["9mobile", "10GB", 2300, 2500],
        ["9mobile", "20GB", 4600, 5000],
        ["9mobile", "40GB", 9200, 10000]
    ];

    const insertPlan = db.prepare(`
        INSERT OR IGNORE INTO data_plans
            (network, plan, provider_cost, selling_price, active)
        VALUES (?, ?, ?, ?, 1)
    `);

    const seedPlans = db.transaction(() => {
        for (const plan of defaultPlans) insertPlan.run(...plan);
    });
    seedPlans();

    db.prepare(`
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            amount REAL NOT NULL,
            status TEXT NOT NULL,
            reference TEXT,
            description TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `).run();
}

function addColumnIfMissing(table, column, definition) {
    const columns = db.prepare(`PRAGMA table_info(${table})`).all();
    const exists = columns.some(existingColumn => existingColumn.name === column);

    if (!exists) {
        db.prepare(`
            ALTER TABLE ${table}
            ADD COLUMN ${column} ${definition}
        `).run();

        console.log(`Added missing column: ${table}.${column}`);
    }
}

function runMigrations() {
    addColumnIfMissing("users", "purchase_pin", "TEXT");
    addColumnIfMissing("users", "virtual_account_number", "TEXT");
    addColumnIfMissing("users", "virtual_bank_name", "TEXT");
    addColumnIfMissing("users", "kyc_status", "TEXT NOT NULL DEFAULT 'pending'");
    addColumnIfMissing("users", "is_admin", "INTEGER NOT NULL DEFAULT 0");
    addColumnIfMissing("users", "reset_token_hash", "TEXT");
    addColumnIfMissing("users", "reset_token_expires_at", "INTEGER");

    // Provider metadata used by WiseSub synchronization and future fulfillment.
    addColumnIfMissing("data_plans", "provider", "TEXT");
    addColumnIfMissing("data_plans", "provider_code", "TEXT");
    addColumnIfMissing("data_plans", "provider_package_code", "TEXT");
    addColumnIfMissing("data_plans", "provider_package_name", "TEXT");
    addColumnIfMissing("data_plans", "data_size", "TEXT");
    addColumnIfMissing("data_plans", "validity", "TEXT");
    addColumnIfMissing("data_plans", "source", "TEXT");
    addColumnIfMissing("data_plans", "last_synced_at", "TEXT");
}

createTables();
runMigrations();

module.exports = {
    db,
    createTables,
    addColumnIfMissing,
    runMigrations
};

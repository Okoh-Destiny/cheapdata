const express = require("express");
const session = require("express-session");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const { WEB_PUBLIC_DIR } = require("./config");
const { db } = require("./db");
const { requireAuth, requireAdmin } = require("./auth");

const app = express();

// =========================
// MIDDLEWARE
// =========================

app.set("trust proxy", 1);

app.use(express.json({ limit: "50kb" }));
app.use(express.urlencoded({ extended: true, limit: "50kb" }));

app.use(session({
    secret: process.env.SESSION_SECRET || "dev-only-insecure-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
        maxAge: 1000 * 60 * 60 * 24 // 24 hours
    }
}));

app.use(express.static(WEB_PUBLIC_DIR));

// =========================
// HELPER FUNCTIONS
// =========================

function generateReference(prefix) {
    return `${prefix}-${Date.now()}-${Math.floor(
        Math.random() * 10000
    )}`;
}

function isValidNigerianPhone(phone) {
    return /^0[7-9][0-1][0-9]{8}$/.test(phone);
}

function getAdmin(userId) {
    return db.prepare(`
        SELECT
            id,
            name,
            email,
            is_admin
        FROM users
        WHERE id = ?
        AND is_admin = 1
    `).get(userId);
}

// =========================
// API STATUS
// =========================

app.get("/api/status", (req, res) => {
    res.json({
        success: true,
        message: "CheapData API is running"
    });
});

// =========================
// REGISTER
// =========================

app.post("/api/register", async (req, res) => {
    try {
        const {
            name,
            email,
            phone,
            password
        } = req.body;

        if (!name || !email || !phone || !password) {
            return res.status(400).json({
                success: false,
                message: "Please fill in all fields"
            });
        }

        if (!isValidNigerianPhone(phone)) {
            return res.status(400).json({
                success: false,
                message: "Please enter a valid Nigerian phone number"
            });
        }

        if (password.length < 6) {
            return res.status(400).json({
                success: false,
                message: "Password must be at least 6 characters"
            });
        }

        const existingUser = db.prepare(`
            SELECT id
            FROM users
            WHERE email = ?
            OR phone = ?
        `).get(email, phone);

        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: "Email or phone number already exists"
            });
        }

        const hashedPassword = await bcrypt.hash(
            password,
            10
        );

        const result = db.prepare(`
            INSERT INTO users (
                name,
                email,
                phone,
                password,
                purchase_pin,
                balance,
                kyc_status,
                is_admin
            )
            VALUES (?, ?, ?, ?, NULL, 0, 'pending', 0)
        `).run(
            name,
            email,
            phone,
            hashedPassword
        );

        const user = db.prepare(`
            SELECT
                id,
                name,
                email,
                phone,
                balance,
                virtual_account_number,
                virtual_bank_name,
                kyc_status,
                is_admin,
                purchase_pin,
                created_at
            FROM users
            WHERE id = ?
        `).get(result.lastInsertRowid);

        const hasPurchasePin = Boolean(
            user.purchase_pin
        );

        delete user.purchase_pin;

        res.json({
            success: true,
            message: "Account created successfully",
            user: {
                ...user,
                has_purchase_pin: hasPurchasePin
            }
        });

    } catch (error) {
        console.error(
            "Registration error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Registration failed"
        });
    }
});

// =========================
// LOGIN
// =========================

app.post("/api/login", async (req, res) => {
    try {
        const {
            email,
            password
        } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: "Email and password are required"
            });
        }

        const user = db.prepare(`
            SELECT *
            FROM users
            WHERE email = ?
        `).get(email);

        if (!user) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            });
        }

        const passwordMatch = await bcrypt.compare(
            password,
            user.password
        );

        if (!passwordMatch) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            });
        }

        req.session.regenerate((err) => {
            if (err) {
                console.error("Session regenerate error:", err);
                return res.status(500).json({
                    success: false,
                    message: "Login failed"
                });
            }

            req.session.userId = user.id;
            finishLogin();
        });

        function finishLogin() {
        res.json({
            success: true,
            message: "Login successful",
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                balance: user.balance,
                virtual_account_number:
                    user.virtual_account_number,
                virtual_bank_name:
                    user.virtual_bank_name,
                kyc_status:
                    user.kyc_status,
                is_admin:
                    user.is_admin,
                has_purchase_pin:
                    Boolean(user.purchase_pin),
                created_at:
                    user.created_at
            }
        });
        }

    } catch (error) {
        console.error(
            "Login error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Login failed"
        });
    }
});

// =========================
// LOGOUT
// =========================

app.post("/api/logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error("Logout error:", err);
            return res.status(500).json({
                success: false,
                message: "Logout failed"
            });
        }

        res.clearCookie("connect.sid");
        res.json({
            success: true,
            message: "Logged out"
        });
    });
});

// =========================
// GET USER
// =========================

app.get("/api/user/:id", requireAuth, (req, res) => {
    try {
        const requestedId = Number(req.params.id);

        if (requestedId !== req.session.userId && !getAdmin(req.session.userId)) {
            return res.status(403).json({
                success: false,
                message: "You can only view your own account"
            });
        }

        const user = db.prepare(`
            SELECT
                id,
                name,
                email,
                phone,
                balance,
                virtual_account_number,
                virtual_bank_name,
                kyc_status,
                is_admin,
                purchase_pin,
                created_at
            FROM users
            WHERE id = ?
        `).get(req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        const hasPurchasePin = Boolean(
            user.purchase_pin
        );

        delete user.purchase_pin;

        res.json({
            success: true,
            user: {
                ...user,
                has_purchase_pin: hasPurchasePin
            }
        });

    } catch (error) {
        console.error(
            "User error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not load user"
        });
    }
});

// =========================
// PURCHASE PIN
// =========================

// SET PURCHASE PIN

app.post("/api/purchase-pin/set", requireAuth, async (req, res) => {
    try {
        const userId = req.session.userId;
        const { pin } = req.body;

        if (pin === undefined) {
            return res.status(400).json({
                success: false,
                message: "PIN is required"
            });
        }

        const pinString = String(pin);

        if (!/^\d{4}$/.test(pinString)) {
            return res.status(400).json({
                success: false,
                message: "Purchase PIN must be exactly 4 digits"
            });
        }

        const user = db.prepare(`
            SELECT
                id,
                purchase_pin
            FROM users
            WHERE id = ?
        `).get(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        if (user.purchase_pin) {
            return res.status(400).json({
                success: false,
                message: "Purchase PIN has already been set"
            });
        }

        const hashedPin = await bcrypt.hash(
            pinString,
            10
        );

        db.prepare(`
            UPDATE users
            SET purchase_pin = ?
            WHERE id = ?
        `).run(
            hashedPin,
            userId
        );

        res.json({
            success: true,
            message: "Purchase PIN created successfully"
        });

    } catch (error) {
        console.error(
            "Set Purchase PIN error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not create Purchase PIN"
        });
    }
});

// CHANGE PURCHASE PIN

app.post("/api/purchase-pin/change", requireAuth, async (req, res) => {
    try {
        const userId = req.session.userId;
        const {
            currentPin,
            newPin
        } = req.body;

        if (
            currentPin === undefined ||
            newPin === undefined
        ) {
            return res.status(400).json({
                success: false,
                message: "All PIN fields are required"
            });
        }

        const currentPinString =
            String(currentPin);

        const newPinString =
            String(newPin);

        if (!/^\d{4}$/.test(currentPinString)) {
            return res.status(400).json({
                success: false,
                message: "Current PIN must be exactly 4 digits"
            });
        }

        if (!/^\d{4}$/.test(newPinString)) {
            return res.status(400).json({
                success: false,
                message: "New PIN must be exactly 4 digits"
            });
        }

        if (currentPinString === newPinString) {
            return res.status(400).json({
                success: false,
                message: "New PIN must be different from current PIN"
            });
        }

        const user = db.prepare(`
            SELECT
                id,
                purchase_pin
            FROM users
            WHERE id = ?
        `).get(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        if (!user.purchase_pin) {
            return res.status(400).json({
                success: false,
                message: "Purchase PIN has not been set"
            });
        }

        const pinCorrect = await bcrypt.compare(
            currentPinString,
            user.purchase_pin
        );

        if (!pinCorrect) {
            return res.status(401).json({
                success: false,
                message: "Current Purchase PIN is incorrect"
            });
        }

        const hashedNewPin = await bcrypt.hash(
            newPinString,
            10
        );

        db.prepare(`
            UPDATE users
            SET purchase_pin = ?
            WHERE id = ?
        `).run(
            hashedNewPin,
            userId
        );

        res.json({
            success: true,
            message: "Purchase PIN changed successfully"
        });

    } catch (error) {
        console.error(
            "Change Purchase PIN error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not change Purchase PIN"
        });
    }
});

// VERIFY PURCHASE PIN

app.post("/api/purchase-pin/verify", requireAuth, async (req, res) => {
    try {
        const userId = req.session.userId;
        const { pin } = req.body;

        if (pin === undefined) {
            return res.status(400).json({
                success: false,
                message: "PIN is required"
            });
        }

        const pinString = String(pin);

        if (!/^\d{4}$/.test(pinString)) {
            return res.status(400).json({
                success: false,
                message: "Purchase PIN must be exactly 4 digits"
            });
        }

        const user = db.prepare(`
            SELECT
                id,
                purchase_pin
            FROM users
            WHERE id = ?
        `).get(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        if (!user.purchase_pin) {
            return res.status(400).json({
                success: false,
                message: "Purchase PIN has not been set"
            });
        }

        const pinCorrect = await bcrypt.compare(
            pinString,
            user.purchase_pin
        );

        if (!pinCorrect) {
            return res.status(401).json({
                success: false,
                message: "Incorrect Purchase PIN"
            });
        }

        res.json({
            success: true,
            message: "Purchase PIN verified"
        });

    } catch (error) {
        console.error(
            "Verify Purchase PIN error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not verify Purchase PIN"
        });
    }
});

// =========================
// TEST FUND
// DEVELOPMENT ONLY
// =========================

app.post("/api/test-fund", requireAuth, (req, res) => {
    try {
        if (process.env.NODE_ENV === "production") {
            return res.status(404).json({
                success: false,
                message: "Not found"
            });
        }

        const userId = req.session.userId;
        const { amount } = req.body;

        const fundAmount = Number(amount);

        if (
            !Number.isFinite(fundAmount) ||
            fundAmount <= 0
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid funding details"
            });
        }

        const user = db.prepare(`
            SELECT
                id,
                balance
            FROM users
            WHERE id = ?
        `).get(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        const reference =
            generateReference("TEST");

        const transaction =
            db.transaction(() => {

                db.prepare(`
                    UPDATE users
                    SET balance = balance + ?
                    WHERE id = ?
                `).run(
                    fundAmount,
                    userId
                );

                db.prepare(`
                    INSERT INTO transactions (
                        user_id,
                        type,
                        amount,
                        status,
                        reference,
                        description
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                `).run(
                    userId,
                    "wallet_funding",
                    fundAmount,
                    "successful",
                    reference,
                    "Development test wallet funding"
                );
            });

        transaction();

        const updatedUser = db.prepare(`
            SELECT balance
            FROM users
            WHERE id = ?
        `).get(userId);

        res.json({
            success: true,
            message: "Wallet funded successfully",
            balance: updatedUser.balance,
            reference
        });

    } catch (error) {
        console.error(
            "Test fund error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not fund wallet"
        });
    }
});

// =========================
// PURCHASE DATA
// =========================

app.post("/api/purchase-data", requireAuth, async (req, res) => {
    try {
        const userId = req.session.userId;
        const {
            network,
            phone,
            plan,
            pin
        } = req.body;

        if (
            !network ||
            !phone ||
            !plan ||
            pin === undefined
        ) {
            return res.status(400).json({
                success: false,
                message: "Please provide all purchase details including your Purchase PIN"
            });
        }

        const pinString = String(pin);

        if (!/^\d{4}$/.test(pinString)) {
            return res.status(400).json({
                success: false,
                message: "Purchase PIN must be exactly 4 digits"
            });
        }

        if (!isValidNigerianPhone(phone)) {
            return res.status(400).json({
                success: false,
                message: "Please enter a valid Nigerian phone number"
            });
        }

        const allowedNetworks = [
            "MTN",
            "Airtel",
            "Glo",
            "9mobile"
        ];

        if (!allowedNetworks.includes(network)) {
            return res.status(400).json({
                success: false,
                message: "Invalid network"
            });
        }

        const selectedPlan = db.prepare(`
            SELECT id, network, plan, provider_cost, selling_price, active
            FROM data_plans
            WHERE network = ?
              AND plan = ?
              AND active = 1
        `).get(network, plan);

        if (!selectedPlan) {
            return res.status(400).json({
                success: false,
                message: "That data plan is not currently available"
            });
        }

        // IMPORTANT: the selling price comes from the server/database.
        // Never trust a price sent by the browser.
        const price = Number(selectedPlan.selling_price);

        const user = db.prepare(`
            SELECT
                id,
                balance,
                purchase_pin
            FROM users
            WHERE id = ?
        `).get(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        if (!user.purchase_pin) {
            return res.status(400).json({
                success: false,
                message: "Please create a Purchase PIN before buying data"
            });
        }

        const pinCorrect = await bcrypt.compare(
            pinString,
            user.purchase_pin
        );

        if (!pinCorrect) {
            return res.status(401).json({
                success: false,
                message: "Incorrect Purchase PIN"
            });
        }

        if (user.balance < price) {
            return res.status(400).json({
                success: false,
                message: "Insufficient wallet balance"
            });
        }

        const reference =
            generateReference("DATA");

        const transaction =
            db.transaction(() => {

                const debitResult = db.prepare(`
                    UPDATE users
                    SET balance = balance - ?
                    WHERE id = ?
                    AND balance >= ?
                `).run(
                    price,
                    userId,
                    price
                );

                if (debitResult.changes !== 1) {
                    throw new Error("Wallet balance changed. Please try again.");
                }

                db.prepare(`
                    INSERT INTO transactions (
                        user_id,
                        type,
                        amount,
                        status,
                        reference,
                        description
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                `).run(
                    userId,
                    "debit",
                    price,
                    "successful",
                    reference,
                    `${network} ${plan} data purchase for ${phone}`
                );
            });

        transaction();

        const updatedUser = db.prepare(`
            SELECT balance
            FROM users
            WHERE id = ?
        `).get(userId);

        res.json({
            success: true,
            message: "Data purchase successful",
            network,
            plan,
            phone,
            amount: price,
            balance: updatedUser.balance,
            reference
        });

    } catch (error) {
        console.error(
            "Data purchase error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Data purchase failed"
        });
    }
});

// =========================
// PURCHASE AIRTIME
// =========================

app.post("/api/purchase-airtime", requireAuth, async (req, res) => {
    try {
        const userId = req.session.userId;
        const {
            network,
            phone,
            amount,
            pin
        } = req.body;

        const airtimeAmount = Number(amount);

        if (
            !network ||
            !phone ||
            !amount ||
            pin === undefined
        ) {
            return res.status(400).json({
                success: false,
                message: "Please provide all purchase details including your Purchase PIN"
            });
        }

        const pinString = String(pin);

        if (!/^\d{4}$/.test(pinString)) {
            return res.status(400).json({
                success: false,
                message: "Purchase PIN must be exactly 4 digits"
            });
        }

        const allowedNetworks = [
            "MTN",
            "Airtel",
            "Glo",
            "9mobile"
        ];

        if (!allowedNetworks.includes(network)) {
            return res.status(400).json({
                success: false,
                message: "Invalid network"
            });
        }

        if (!isValidNigerianPhone(phone)) {
            return res.status(400).json({
                success: false,
                message: "Please enter a valid Nigerian phone number"
            });
        }

        if (
            !Number.isFinite(airtimeAmount) ||
            airtimeAmount < 50 ||
            airtimeAmount > 50000
        ) {
            return res.status(400).json({
                success: false,
                message: "Airtime amount must be between ₦50 and ₦50,000"
            });
        }

        const user = db.prepare(`
            SELECT
                id,
                balance,
                purchase_pin
            FROM users
            WHERE id = ?
        `).get(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        if (!user.purchase_pin) {
            return res.status(400).json({
                success: false,
                message: "Please create a Purchase PIN before buying airtime"
            });
        }

        const pinCorrect = await bcrypt.compare(
            pinString,
            user.purchase_pin
        );

        if (!pinCorrect) {
            return res.status(401).json({
                success: false,
                message: "Incorrect Purchase PIN"
            });
        }

        if (user.balance < airtimeAmount) {
            return res.status(400).json({
                success: false,
                message: "Insufficient wallet balance"
            });
        }

        const reference =
            generateReference("AIRTIME");

        const transaction =
            db.transaction(() => {

                const debitResult = db.prepare(`
                    UPDATE users
                    SET balance = balance - ?
                    WHERE id = ?
                    AND balance >= ?
                `).run(
                    airtimeAmount,
                    userId,
                    airtimeAmount
                );

                if (debitResult.changes !== 1) {
                    throw new Error("Wallet balance changed. Please try again.");
                }

                db.prepare(`
                    INSERT INTO transactions (
                        user_id,
                        type,
                        amount,
                        status,
                        reference,
                        description
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                `).run(
                    userId,
                    "debit",
                    airtimeAmount,
                    "successful",
                    reference,
                    `${network} airtime purchase for ${phone}`
                );
            });

        transaction();

        const updatedUser = db.prepare(`
            SELECT balance
            FROM users
            WHERE id = ?
        `).get(userId);

        res.json({
            success: true,
            message: "Airtime purchase successful",
            network,
            phone,
            amount: airtimeAmount,
            balance: updatedUser.balance,
            reference
        });

    } catch (error) {
        console.error(
            "Airtime purchase error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Airtime purchase failed"
        });
    }
});

// =========================
// USER TRANSACTIONS
// =========================

app.get("/api/transactions/:userId", requireAuth, (req, res) => {
    try {
        const requestedId = Number(req.params.userId);

        if (requestedId !== req.session.userId && !getAdmin(req.session.userId)) {
            return res.status(403).json({
                success: false,
                message: "You can only view your own transactions"
            });
        }

        const transactions = db.prepare(`
            SELECT
                id,
                type,
                amount,
                status,
                reference,
                description,
                created_at
            FROM transactions
            WHERE user_id = ?
            ORDER BY id DESC
        `).all(requestedId);

        res.json({
            success: true,
            transactions
        });

    } catch (error) {
        console.error(
            "Transactions error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not load transactions"
        });
    }
});

// =========================
// DATA PLANS
// =========================

// Public: customer-facing active plans.
app.get("/api/data-plans", (req, res) => {
    try {
        const plans = db.prepare(`
            SELECT id, network, plan, selling_price
            FROM data_plans
            WHERE active = 1
            ORDER BY
                CASE network
                    WHEN 'MTN' THEN 1
                    WHEN 'Airtel' THEN 2
                    WHEN 'Glo' THEN 3
                    WHEN '9mobile' THEN 4
                    ELSE 5
                END,
                id ASC
        `).all();

        res.json({ success: true, plans });
    } catch (error) {
        console.error("Data plans error:", error);
        res.status(500).json({ success: false, message: "Could not load data plans" });
    }
});

// Admin: all plans, including inactive ones.
app.get("/api/admin/data-plans", requireAuth, requireAdmin, (req, res) => {
    try {
        const plans = db.prepare(`
            SELECT id, network, plan, provider_cost, selling_price,
                   (selling_price - provider_cost) AS margin, active,
                   created_at, updated_at
            FROM data_plans
            ORDER BY
                CASE network
                    WHEN 'MTN' THEN 1
                    WHEN 'Airtel' THEN 2
                    WHEN 'Glo' THEN 3
                    WHEN '9mobile' THEN 4
                    ELSE 5
                END, id ASC
        `).all();

        res.json({ success: true, plans });
    } catch (error) {
        console.error("Admin data plans error:", error);
        res.status(500).json({ success: false, message: "Could not load data plans" });
    }
});

app.post("/api/admin/data-plans", requireAuth, requireAdmin, (req, res) => {
    try {
        const network = String(req.body.network || "").trim();
        const plan = String(req.body.plan || "").trim();
        const providerCost = Number(req.body.provider_cost);
        const sellingPrice = Number(req.body.selling_price);
        const active = req.body.active === undefined ? 1 : (Number(req.body.active) ? 1 : 0);

        const allowedNetworks = ["MTN", "Airtel", "Glo", "9mobile"];
        if (!allowedNetworks.includes(network)) {
            return res.status(400).json({ success: false, message: "Invalid network" });
        }
        if (!/^\d+(?:\.\d+)?(?:MB|GB)$/i.test(plan)) {
            return res.status(400).json({ success: false, message: "Invalid plan format. Example: 1GB or 500MB" });
        }
        if (!Number.isFinite(providerCost) || providerCost < 0) {
            return res.status(400).json({ success: false, message: "Provider cost must be 0 or greater" });
        }
        if (!Number.isFinite(sellingPrice) || sellingPrice <= 0) {
            return res.status(400).json({ success: false, message: "Selling price must be greater than 0" });
        }
        if (sellingPrice < providerCost) {
            return res.status(400).json({ success: false, message: "Selling price cannot be below provider cost" });
        }

        const result = db.prepare(`
            INSERT INTO data_plans (network, plan, provider_cost, selling_price, active, updated_at)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(network, plan) DO UPDATE SET
                provider_cost = excluded.provider_cost,
                selling_price = excluded.selling_price,
                active = excluded.active,
                updated_at = CURRENT_TIMESTAMP
        `).run(network, plan.toUpperCase(), providerCost, sellingPrice, active);

        const saved = db.prepare(`SELECT id, network, plan, provider_cost, selling_price, active,
            (selling_price - provider_cost) AS margin, updated_at
            FROM data_plans WHERE network = ? AND plan = ?`).get(network, plan.toUpperCase());

        res.json({ success: true, message: "Data plan saved successfully", plan: saved });
    } catch (error) {
        console.error("Save data plan error:", error);
        res.status(500).json({ success: false, message: "Could not save data plan" });
    }
});

app.patch("/api/admin/data-plans/:id", requireAuth, requireAdmin, (req, res) => {
    try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) {
            return res.status(400).json({ success: false, message: "Invalid plan ID" });
        }

        const current = db.prepare(`SELECT * FROM data_plans WHERE id = ?`).get(id);
        if (!current) return res.status(404).json({ success: false, message: "Data plan not found" });

        const providerCost = req.body.provider_cost === undefined ? Number(current.provider_cost) : Number(req.body.provider_cost);
        const sellingPrice = req.body.selling_price === undefined ? Number(current.selling_price) : Number(req.body.selling_price);
        const active = req.body.active === undefined ? Number(current.active) : (Number(req.body.active) ? 1 : 0);

        if (!Number.isFinite(providerCost) || providerCost < 0 || !Number.isFinite(sellingPrice) || sellingPrice <= 0) {
            return res.status(400).json({ success: false, message: "Invalid pricing values" });
        }
        if (sellingPrice < providerCost) {
            return res.status(400).json({ success: false, message: "Selling price cannot be below provider cost" });
        }

        db.prepare(`
            UPDATE data_plans
            SET provider_cost = ?, selling_price = ?, active = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `).run(providerCost, sellingPrice, active, id);

        const saved = db.prepare(`SELECT id, network, plan, provider_cost, selling_price, active,
            (selling_price - provider_cost) AS margin, updated_at
            FROM data_plans WHERE id = ?`).get(id);

        res.json({ success: true, message: "Data plan updated successfully", plan: saved });
    } catch (error) {
        console.error("Update data plan error:", error);
        res.status(500).json({ success: false, message: "Could not update data plan" });
    }
});

// =========================
// ADMIN STATS
// =========================

app.get("/api/admin/stats", requireAuth, requireAdmin, (req, res) => {
    try {
        const totalUsers = db.prepare(`
            SELECT COUNT(*) AS count
            FROM users
        `).get().count;

        const totalBalance = db.prepare(`
            SELECT COALESCE(SUM(balance), 0) AS total
            FROM users
        `).get().total;

        const totalTransactions = db.prepare(`
            SELECT COUNT(*) AS count
            FROM transactions
        `).get().count;

        const dataPurchases = db.prepare(`
            SELECT COUNT(*) AS count
            FROM transactions
            WHERE type = 'debit'
            AND status = 'successful'
            AND description LIKE '%data purchase%'
        `).get().count;

        const airtimePurchases = db.prepare(`
            SELECT COUNT(*) AS count
            FROM transactions
            WHERE type = 'debit'
            AND status = 'successful'
            AND description LIKE '%airtime purchase%'
        `).get().count;

        const totalRevenue = db.prepare(`
            SELECT COALESCE(SUM(amount), 0) AS total
            FROM transactions
            WHERE type = 'debit'
            AND status = 'successful'
            AND (
                description LIKE '%data purchase%'
                OR description LIKE '%airtime purchase%'
            )
        `).get().total;

        res.json({
            success: true,
            stats: {
                totalUsers,
                totalBalance,
                totalTransactions,
                dataPurchases,
                airtimePurchases,
                totalRevenue
            }
        });

    } catch (error) {
        console.error(
            "Admin stats error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not load admin statistics"
        });
    }
});

// =========================
// ADMIN USERS
// =========================

app.get("/api/admin/users", requireAuth, requireAdmin, (req, res) => {
    try {
        const users = db.prepare(`
            SELECT
                id,
                name,
                email,
                phone,
                balance,
                virtual_account_number,
                virtual_bank_name,
                kyc_status,
                is_admin,
                created_at
            FROM users
            ORDER BY id DESC
        `).all();

        res.json({
            success: true,
            users
        });

    } catch (error) {
        console.error(
            "Admin users error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not load users"
        });
    }
});

// =========================
// ADMIN TRANSACTIONS
// =========================

app.get("/api/admin/transactions", requireAuth, requireAdmin, (req, res) => {
    try {
        const transactions = db.prepare(`
            SELECT
                transactions.id,
                users.name AS user_name,
                users.email AS user_email,
                transactions.type,
                transactions.amount,
                transactions.status,
                transactions.reference,
                transactions.description,
                transactions.created_at
            FROM transactions
            INNER JOIN users
                ON users.id = transactions.user_id
            ORDER BY transactions.id DESC
            LIMIT 100
        `).all();

        res.json({
            success: true,
            transactions
        });

    } catch (error) {
        console.error(
            "Admin transactions error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Could not load admin transactions"
        });
    }
});

// =========================
// SERVER
// =========================

// =========================
// FORGOT PASSWORD
// =========================

app.post("/api/forgot-password", (req, res) => {
    try {
        const email = String(req.body.email || "").trim().toLowerCase();

        if (!email) {
            return res.status(400).json({
                success: false,
                message: "Please enter your email address."
            });
        }

        const user = db.prepare(`
            SELECT id, email
            FROM users
            WHERE LOWER(email) = ?
        `).get(email);

        // Always return the same message whether the email exists or not.
        // This helps prevent account enumeration.
        if (!user) {
            return res.json({
                success: true,
                message:
                    "If an account exists with that email, password reset instructions will be provided."
            });
        }

        // Generate a secure random reset token
        const resetToken = crypto.randomBytes(32).toString("hex");

        // Store only the SHA-256 hash of the token
        const resetTokenHash = crypto
            .createHash("sha256")
            .update(resetToken)
            .digest("hex");

        // Token expires in 15 minutes
        const expiresAt = Date.now() + (15 * 60 * 1000);

        db.prepare(`
            UPDATE users
            SET reset_token_hash = ?,
                reset_token_expires_at = ?
            WHERE id = ?
        `).run(
            resetTokenHash,
            expiresAt,
            user.id
        );

        // DEVELOPMENT ONLY:
        // This prints the reset link in the terminal.
        const resetUrl =
            `http://localhost:3000/reset-password.html?token=${resetToken}`;

        console.log("");
        console.log("======================================");
        console.log("PASSWORD RESET REQUEST");
        console.log("======================================");
        console.log(`Email: ${user.email}`);
        console.log(`Reset link: ${resetUrl}`);
        console.log("Expires in: 15 minutes");
        console.log("======================================");
        console.log("");

        return res.json({
            success: true,
            message:
                "If an account exists with that email, password reset instructions will be provided."
        });

    } catch (error) {
        console.error("Forgot password error:", error);

        return res.status(500).json({
            success: false,
            message: "Something went wrong. Please try again."
        });
    }
});
// =========================
// RESET PASSWORD
// =========================

app.post("/api/reset-password", async (req, res) => {
    try {
        const { token, newPassword } = req.body;

        if (!token || !newPassword) {
            return res.status(400).json({
                success: false,
                message: "Reset token and new password are required."
            });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({
                success: false,
                message: "Password must be at least 6 characters."
            });
        }

        // Hash the token received from the reset link
        const tokenHash = crypto
            .createHash("sha256")
            .update(token)
            .digest("hex");

        // Find a user with this token
        const user = db.prepare(`
            SELECT id, reset_token_hash, reset_token_expires_at
            FROM users
            WHERE reset_token_hash = ?
        `).get(tokenHash);

        if (!user) {
            return res.status(400).json({
                success: false,
                message: "This password reset link is invalid or has already been used."
            });
        }

        // Check whether the token has expired
        if (
            !user.reset_token_expires_at ||
            Date.now() > user.reset_token_expires_at
        ) {
            return res.status(400).json({
                success: false,
                message: "This password reset link has expired. Please request a new one."
            });
        }

        // Hash the new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Save the new password and invalidate the reset token
        db.prepare(`
            UPDATE users
            SET password = ?,
                reset_token_hash = NULL,
                reset_token_expires_at = NULL
            WHERE id = ?
        `).run(
            hashedPassword,
            user.id
        );

        return res.json({
            success: true,
            message: "Password reset successfully. You can now log in."
        });

    } catch (error) {
        console.error("Reset password error:", error);

        return res.status(500).json({
            success: false,
            message: "Something went wrong. Please try again."
        });
    }
});

    // =========================
// FUND WALLET - PAYSTACK
// =========================

app.post("/api/fund-wallet", requireAuth, async (req, res) => {
    try {
        const { amount } = req.body;

        const numericUserId = req.session.userId;
        const fundingAmount = Number(amount);

        // Validate amount
        if (
            !Number.isInteger(fundingAmount) ||
            fundingAmount < 100 ||
            fundingAmount > 500000
        ) {
            return res.status(400).json({
                success: false,
                message: "Funding amount must be between ₦100 and ₦500,000."
            });
        }

        // Find the user from the database
        const user = db.prepare(`
            SELECT id, email
            FROM users
            WHERE id = ?
        `).get(numericUserId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User account not found."
            });
        }

        // Make sure Paystack secret key exists
        if (!process.env.PAYSTACK_SECRET_KEY) {
            console.error("PAYSTACK_SECRET_KEY is missing.");

            return res.status(500).json({
                success: false,
                message: "Payment system is not configured yet."
            });
        }

        // Generate a unique reference
        const reference =
            `CD-${Date.now()}-${crypto.randomBytes(6).toString("hex")}`;

        // Paystack expects the amount in kobo
        const amountInKobo = fundingAmount * 100;

        const paystackResponse = await fetch(
            "https://api.paystack.co/transaction/initialize",
            {
                method: "POST",

                headers: {
                    "Authorization":
                        `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,

                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    email: user.email,
                    amount: String(amountInKobo),
                    currency: "NGN",
                    reference: reference,
                    callback_url: `${req.protocol}://${req.get("host")}/fund-wallet.html`,

                    metadata: {
                        user_id: String(user.id),
                        purpose: "wallet_funding"
                    }
                })
            }
        );

        const paystackData = await paystackResponse.json();

        if (
            !paystackResponse.ok ||
            !paystackData.status ||
            !paystackData.data
        ) {
            console.error(
                "Paystack initialization failed:",
                paystackData
            );

            return res.status(400).json({
                success: false,
                message:
                    paystackData.message ||
                    "Unable to initialize payment."
            });
        }

        // Record the funding attempt before sending the customer to Paystack.
        // The wallet is NOT credited here. Credit happens only after server-side
        // verification in /api/fund-wallet/verify.
        db.prepare(`
            INSERT INTO transactions (
                user_id, type, amount, status, reference, description
            )
            VALUES (?, ?, ?, ?, ?, ?)
        `).run(
            user.id,
            "wallet_funding",
            fundingAmount,
            "pending",
            paystackData.data.reference,
            "Paystack wallet funding"
        );

        return res.json({
            success: true,
            message: "Payment initialized successfully.",
            authorization_url:
                paystackData.data.authorization_url,
            access_code:
                paystackData.data.access_code,
            reference:
                paystackData.data.reference
        });

    } catch (error) {

        console.error(
            "Fund wallet error:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Unable to initialize payment. Please try again."
        });
    }
});

// =========================
// VERIFY PAYSTACK WALLET FUNDING
// =========================

app.post("/api/fund-wallet/verify", requireAuth, async (req, res) => {
    try {
        const reference = String(req.body.reference || "").trim();

        if (!reference || reference.length > 100) {
            return res.status(400).json({
                success: false,
                message: "A valid payment reference is required."
            });
        }

        if (!process.env.PAYSTACK_SECRET_KEY) {
            return res.status(500).json({
                success: false,
                message: "Payment system is not configured yet."
            });
        }

        const transaction = db.prepare(`
            SELECT id, user_id, amount, status, reference
            FROM transactions
            WHERE reference = ?
              AND type = 'wallet_funding'
              AND user_id = ?
            LIMIT 1
        `).get(reference, req.session.userId);

        if (!transaction) {
            return res.status(404).json({
                success: false,
                message: "Funding transaction not found."
            });
        }

        // Idempotency: never credit an already-successful payment twice.
        if (transaction.status === "successful") {
            const user = db.prepare(`SELECT balance FROM users WHERE id = ?`).get(req.session.userId);
            return res.json({
                success: true,
                message: "Payment has already been credited.",
                balance: user.balance,
                reference
            });
        }

        const paystackResponse = await fetch(
            `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
            {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${process.env.PAYSTACK_SECRET_KEY}`
                }
            }
        );

        const paystackData = await paystackResponse.json();

        if (!paystackResponse.ok || !paystackData.status || !paystackData.data) {
            return res.status(400).json({
                success: false,
                message: paystackData.message || "Unable to verify payment."
            });
        }

        const payment = paystackData.data;
        const expectedAmount = Math.round(Number(transaction.amount) * 100);
        const paidAmount = Number(payment.amount);
        const metadataUserId = String(
            payment.metadata && payment.metadata.user_id || ""
        );

        if (
            payment.status !== "success" ||
            payment.currency !== "NGN" ||
            paidAmount !== expectedAmount ||
            metadataUserId !== String(req.session.userId) ||
            String(payment.reference) !== reference
        ) {
            return res.status(400).json({
                success: false,
                message: "Payment could not be verified as a valid CheapData wallet funding."
            });
        }

        const credit = db.transaction(() => {
            const current = db.prepare(`
                SELECT status, user_id, amount
                FROM transactions
                WHERE id = ?
            `).get(transaction.id);

            if (!current || current.status === "successful") {
                return false;
            }

            db.prepare(`
                UPDATE users
                SET balance = balance + ?
                WHERE id = ?
            `).run(current.amount, current.user_id);

            db.prepare(`
                UPDATE transactions
                SET status = 'successful',
                    description = ?
                WHERE id = ?
            `).run(
                "Verified Paystack wallet funding",
                transaction.id
            );

            return true;
        });

        const credited = credit();
        const user = db.prepare(`SELECT balance FROM users WHERE id = ?`).get(req.session.userId);

        return res.json({
            success: true,
            message: credited
                ? "Payment verified and wallet credited successfully."
                : "Payment has already been credited.",
            balance: user.balance,
            amount: transaction.amount,
            reference
        });
    } catch (error) {
        console.error("Paystack verification error:", error);
        return res.status(500).json({
            success: false,
            message: "Unable to verify payment right now. Please try again."
        });
    }
});

module.exports = {
    app,
    db
};